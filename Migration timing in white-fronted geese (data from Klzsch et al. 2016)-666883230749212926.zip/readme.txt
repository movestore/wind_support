This annotated dataset comes from the Environmental Data Automated Track Annotation System (Env-DATA) on Movebank (movebank.org). The environmental data attributes are created and distributed by government and research organizations. For general information on the Env-DATA System, see Dodge et al. (2013) and movebank.org/node/6607.

Terms of Use: Verify the terms of use for relevant tracking data and environmental datasets prior to presenting or publishing these data. Terms of use for animal movement data in Movebank are defined by the study owners in the License Terms for the study. Terms of use for environmental datasets vary by provider; see below for details. When using these results in presentations or publications, acknowledge the use of Env-DATA and Movebank and cite Dodge et al. (2013). Sample acknowledgement: "[source product/variable] values were annotated using the Env-DATA System on Movebank (movebank.org)." Please send copies of published work to support@movebank.org.

Contact: support@movebank.org. Include the access key below with questions about this request.

---------------------------

Annotated data for the following Movebank entities are contained in this file:
Movebank study name: Migration timing in white-fronted geese (data from Kölzsch et al. 2016)
Annotated Animal IDs: 700, 701, 707, 709, 712, 716, 720, 727, 738, 742, 749, 762, 768, 3084, 3097, 3104, 3271, 728, 733, 736, 744, 746, 764, 767, 3067, 3088, 3098, 3103, 730, 750, 2704, and more ...
Requested on Mon May 02 12:00:15 CEST 2022
Access key: 666883230749212926
Requested by: Andrea Kölzsch

---------------------------

File attributes

Attributes from the Movebank database (see the Movebank Attribute Dictionary at http://www.movebank.org/node/2381):
Location Lat: latitude in decimal degrees, WGS84 reference system
Location Long: longitude in decimal degrees, WGS84 reference system
Timestamp: the time of the animal location estimates, in UTC
Height Above Ellipsoid: the height above the ellipsoid returned by the GPS unit
Migration Stage Custom
Heading
Migration Stage Standard
Update Ts

Locations are the the geographic coordinates of locations along an animal track as estimated by the processed sensor data.


---------------------------

Attributes from annotated environmental data:
Name: ECMWF ERA5 SL Wind (10 m above Ground U Component)
Description: Velocity of the east-west (zonal) component of wind at 10 m above the surface of the earth. Positive values indicate flow from west to east. Care should be taken when comparing this parameter with observations, because wind observations vary on small space and time scales and are affected by the local terrain, vegetation and buildings that are represented only on average in the ECMWF Integrated Forecasting System. This parameter can be combined with the V component of 10m wind to give the speed and direction of the horizontal 10m wind.
Unit: m/s
No data values: NaN (interpolated)
Interpolation: bilinear

Name: ECMWF ERA5 SL Wind (10 m above Ground V Component)
Description: Velocity of the north-south (meridional) component of wind at 10 m above the surface of the earth. Positive values indicate flow from south to north. Care should be taken when comparing this parameter with observations, because wind observations vary on small space and time scales and are affected by the local terrain, vegetation and buildings that are represented only on average in the ECMWF Integrated Forecasting System. This parameter can be combined with the U component of 10m wind to give the speed and direction of the horizontal 10m wind.
Unit: m/s
No data values: NaN (interpolated)
Interpolation: bilinear

---------------------------

Environmental data services

Service: ECMWF Global Atmospheric Reanalysis/ERA5 Single Levels
Provider: European Centre for Medium-Range Weather Forecasts
Datum: N/A
Projection: N/A
Spatial granularity: 0.25 degrees
Spatial range (long x lat): E: 180.0    W: -180.0 x N: 89.463    S: -89.463
Temporal granularity: hourly
Temporal range: 1979-01-01 to present
Source link: https://doi.org/10.24381/cds.adbb2d47
Terms of use: https://confluence.ecmwf.int/display/CKB/How+to+acknowledge%2C+cite+and+reference+data+published+on+the+Climate+Data+Store
Related websites:
https://doi.org/10.24381/cds.adbb2d47

---------------------------

Dodge S, Bohrer G, Weinzierl R, Davidson SC, Kays R, Douglas D, Cruz S, Han J, Brandes D, Wikelski M (2013) The Environmental-Data Automated Track Annotation (Env-DATA) System: linking animal tracks with environmental data. Movement Ecology 1:3. doi:10.1186/2051-3933-1-3

Development and maintenance of Env-DATA is funded by the Max Planck Society, and has been supported by US National Science Foundation Biological Infrastructure award 1564380, NASA ABoVE project NNX15AT91A, and NASA Earth Science Division, Ecological Forecasting Program Project NNX11AP61G.